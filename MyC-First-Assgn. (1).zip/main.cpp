#include <iostream>
using namespace std;

int main(){

    //declare and initialize variables
    int a=10;
    int b=20;
    int c;

    //add the two numbers
    c=a+b;

    //display the result
    cout<< "Sum of" << a << "and"<< b << "is:" << c << endl;

    return 0;
}
    